[Description](http://speech.ee.ntu.edu.tw/~tlkagk/courses/ML_2017/Lecture/HW0.mp4)




- **Q1 矩阵运算**   
   
  读取matrixA.txt and matrixB.txt   
   
  进行矩阵乘法运算    
     
  由大到小排序后输出   
     
  numpy   
  

  
  
- **Q2 图像处理**  
  
  读取两个图片  
    
  使用后者异于前者的部分产生相同格式的新图片  
  
  pillow
